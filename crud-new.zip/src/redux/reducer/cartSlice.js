import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  product: [],
};

const cartSlice = createSlice({
  name: "cart",
  initialState,
  reducers: {
    add(state, action) {
      // console.log("this is state" + state);
      state.product.push(action.payload);
    },
    remove(state, action) {
      const updatedData = state.product.filter(
        (item) => item.id !== action.payload
      );
      state.product = updatedData;
    },
  },
});

export const { add, remove } = cartSlice.actions;
export default cartSlice.reducer;
