import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { BsCart2 } from "react-icons/bs";

function Header() {
  const { product } = useSelector((state) => state.cart);
  const cartLength = product.length;
  return (
    <div className=" ml-10 ">
      <div className=" relative pl-2  ">
        <Link to="/cart" className="px-3    transform delay-100">
          {cartLength != 0 ? (
            <span className="absolute rounded-full text-sm top-4 w-5 my-auto h-5 text-center bg-red-400 text-white px-1">
              {cartLength}
            </span>
          ) : null}

          <span className="inline">
            <BsCart2 size={25} />
          </span>
        </Link>
      </div>
    </div>
  );
}

export default Header;
