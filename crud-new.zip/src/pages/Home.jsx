import axios from "axios";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import { add } from "../redux/reducer/cartSlice";

function Home() {
  const [readData, setReadData] = useState([]);
  const dispatch = useDispatch();

  useEffect(() => {
    getData();
  }, []);

  async function getData() {
    try {
      const Response = await axios.get(
        "https://65b6463cda3a3c16ab0079c2.mockapi.io/crud-pract"
      );
      setReadData(Response.data);
    } catch (error) {
      console.log(error);
    }
  }

  const handleAdd = (data) => {
    dispatch(add(data));
    alert("Your Product is Added successfully");
  };

  return (
    <>
      {/* header */}
      <div className="bg-blue-50">
        <div className="w-11/12 mx-auto text-red-950 py-5 flex justify-between items-center">
          <h1 className="text-center text-blue-950 my-2 text-xl">
            CRUD Operation
          </h1>
          <div>
            <Link to="create">
              <button className="bg-red-950 text-white px-2 py-1">
                Add Product
              </button>
            </Link>
          </div>
        </div>
      </div>

      {/* body */}
      <div className="w-11/12 mx-auto">
        <h2 className="text-center text-2xl py-5 font-bold">All Products</h2>
        <div className="my-10">
          <div className="grid grid-cols-1 sm:grid-cols-2 sm:gap-5">
            {readData.map((item, i) => (
              <div
                key={i}
                className="bg-[#eee] p-5 flex flex-col  items-center justify-center"
              >
                <h2 className=" text-center text-blue-950 text-xl py-2">
                  {item.product}
                </h2>

                <p className="text-lg pb-2">{item.desc}</p>
                <div className="mx-auto flex gap-x-5">
                  <Link to={`/product/${item.id}`}>
                    <button className="bg-red-950 text-white px-2 py-1">
                      Show All Detail
                    </button>
                  </Link>

                  <button
                    onClick={() => handleAdd(item)}
                    className="bg-red-950 text-white px-2 py-1"
                  >
                    Add to Cart
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

export default Home;
