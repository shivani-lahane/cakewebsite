import axios from "axios";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";
import { add } from "../redux/reducer/cartSlice";

function Product() {
  const [productData, setProductData] = useState();
  const dispatch = useDispatch();
  // Method 1
  // const prodId=useParams();
  // const id=prodId.id;
  //OR Method 2
  const { id } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    async function PostData() {
      try {
        const response = await axios.get(
          `https://65b6463cda3a3c16ab0079c2.mockapi.io/crud-pract/${id}`
        );
        setProductData(response.data);
      } catch (error) {
        console.log(error);
      }
    }

    PostData();
  }, [id]);

  const handleDelete = async () => {
    try {
      await axios.delete(
        `https://65b6463cda3a3c16ab0079c2.mockapi.io/crud-pract/${id}`
      );
      navigate("/");
    } catch (error) {
      console.log(error);
    }
  };

  const handleUpdate = () => {
    localStorage.setItem("id", productData.id);
    localStorage.setItem("product", productData.product);
    localStorage.setItem("desc", productData.desc);
    localStorage.setItem("imgUrl", productData.imgUrl);
    navigate("/update");
  };

  const handleAdd = (data) => {
    dispatch(add(data));
    navigate("/");
    alert("Your Product is Added successfully");
  };
  return (
    <div>
      <div className="w-11/12 mx-auto">
        <div className="flex justify-between py-10">
          <h2>Single Product</h2>
          <div className="flex gap-x-5">
            <button
              onClick={handleUpdate}
              className="bg-red-950 text-white px-2 py-1"
            >
              Edit
            </button>

            <button
              onClick={handleDelete}
              className="bg-red-950 text-white px-2 py-1"
            >
              Delete
            </button>
          </div>
        </div>
        <div className="">
          <div className="p-5 flex flex-col  items-center justify-center">
            <h2 className=" text-center text-blue-950 text-xl py-2">
              {productData?.product}
            </h2>

            <p className="text-lg pb-2">{productData?.desc}</p>
            <img src={productData?.imgUrl} alt="product" className="" />

            <div className="flex gap-x-10">
              <button
                onClick={() => handleAdd(productData)}
                className="bg-red-950 text-white px-2 py-1 my-5"
              >
                Add to Cart
              </button>
              <button
                onClick={() => navigate(-1)}
                className="bg-red-950 text-white px-2 py-1 my-5"
              >
                Back
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Product;
